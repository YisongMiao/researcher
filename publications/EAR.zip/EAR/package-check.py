# This file is to see if your environment is fine

# Random packages
import random
import torch
import torch.nn as nn
import json
import pickle
import numpy as np
import time

# Torch
from torch.nn import functional as F

from torch.autograd import gradcheck


def main():
    print('BB8 and R2D2 are best friends')
    print('All packages fine')


if __name__ == '__main__':
    main()
